/// <reference types="cypress" />
import TagFixtures from '../fixtures/tags.json';

context('Tags', () => {
    beforeEach(() => {
        cy.visit('/index.html');
    });

    it('Add new tag', () => {
        cy.get('#tagsList li#addTag')
            .should('have.text', '建立標籤')
            .click();

        cy.get('#dialog')
            .should('be.visible')
            .children('h2.title')
            .should('have.text', '建立標籤');

        let newTagName = TagFixtures.newTag1;

        cy.get('#dialog form.newTag')
            .children('input[name="name"]')
            .type(newTagName, {delay: 10})
            .should('have.value', newTagName)
            .parent()
            .children('button.submit')
            .click();

        cy.get('#tagsList li.item:contains(' + newTagName + ')')
            .its('length')
            .should('be.gte', 1);

        // Ensure data does not store in localStorage
        cy.window().then((win) => {
            win.sessionStorage.clear()
        })
            .clearLocalStorage()
            .clearCookies();

        cy.reload();
        cy.get('#tagsList li.item:contains(' + newTagName + ')')
            .its('length')
            .should('be.gte', 1);
    });
});
